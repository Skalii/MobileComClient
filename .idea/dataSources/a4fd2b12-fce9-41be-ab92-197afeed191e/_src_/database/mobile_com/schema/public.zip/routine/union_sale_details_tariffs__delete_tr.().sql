create function union_sale_details_tariffs__delete_tr() returns trigger
LANGUAGE plpgsql
AS $$
BEGIN
			UPDATE sale_details
			SET ids_tariff = ids_tariff - OLD.id_tariff
			WHERE id_sale_detail = OLD.id_sale_detail;
			
			RETURN OLD;
		END;

$$;
