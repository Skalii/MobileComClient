create function union_sale_details_phones__update_tr() returns trigger
LANGUAGE plpgsql
AS $$
BEGIN
			UPDATE sale_details
			SET ids_phone = ids_phone - OLD.id_phone
			WHERE id_sale_detail = OLD.id_sale_detail;
			
			UPDATE sale_details
			SET ids_phone = ids_phone + NEW.id_phone
			WHERE id_sale_detail = NEW.id_sale_detail;

			RETURN NEW;
		END;

$$;
