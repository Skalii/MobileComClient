create function union_sale_details_phones__truncate_tr() returns trigger
LANGUAGE plpgsql
AS $$
BEGIN
			UPDATE sale_details
			SET ids_phone = ARRAY[]::INTEGER[];

			RETURN NULL;
		END;

$$;
