create function union_sale_details_tariffs__truncate_tr() returns trigger
LANGUAGE plpgsql
AS $$
BEGIN
			UPDATE sale_details
			SET ids_tariff = ARRAY[]::INTEGER[];

			RETURN NULL;
		END;

$$;
