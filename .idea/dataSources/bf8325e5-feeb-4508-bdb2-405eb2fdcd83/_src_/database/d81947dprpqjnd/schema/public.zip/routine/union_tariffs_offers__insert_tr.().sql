create function union_tariffs_offers__insert_tr() returns trigger
LANGUAGE plpgsql
AS $$
BEGIN
  UPDATE tariffs
  SET ids_offer = ids_offer + NEW.id_offer
  WHERE id_tariff = NEW.id_tariff;

  RETURN NEW;
END;
$$;
