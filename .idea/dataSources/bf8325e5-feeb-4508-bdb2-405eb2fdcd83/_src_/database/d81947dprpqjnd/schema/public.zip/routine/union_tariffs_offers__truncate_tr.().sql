create function union_tariffs_offers__truncate_tr() returns trigger
LANGUAGE plpgsql
AS $$
BEGIN
  UPDATE tariffs
  SET ids_offer = ARRAY[]::INTEGER[];

  RETURN NULL;
END;
$$;
