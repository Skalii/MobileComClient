create function union_sale_details_tariffs__update_tr() returns trigger
LANGUAGE plpgsql
AS $$
BEGIN
  UPDATE sale_details
  SET ids_tariff = ids_tariff - OLD.id_tariff
  WHERE id_sale_detail = OLD.id_sale_detail;

  UPDATE sale_details
  SET ids_tariff = ids_tariff + NEW.id_tariff
  WHERE id_sale_detail = NEW.id_sale_detail;

  RETURN NEW;
END;
$$;
